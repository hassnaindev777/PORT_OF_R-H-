// Accommodation Finder backend. Zero dependencies. Needs Node 22.5+.
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const {DatabaseSync}=require('node:sqlite');
// optional .env loader
try{fs.readFileSync(path.join(__dirname,'.env'),'utf8').split('\n').forEach(l=>{const m=l.match(/^\s*([A-Z_]+)\s*=\s*(.*)\s*$/);if(m&&!l.trim().startsWith('#')&&!(m[1] in process.env))process.env[m[1]]=m[2]})}catch(e){}
const PORT=+process.env.PORT||3000, DB_FILE=process.env.DB_FILE||path.join(__dirname,'data.db');
let SECRET=process.env.SECRET;
if(!SECRET){const f=path.join(__dirname,'.secret');try{SECRET=fs.readFileSync(f,'utf8')}catch(e){SECRET=crypto.randomBytes(32).toString('hex');fs.writeFileSync(f,SECRET,{mode:0o600})}}

const db=new DatabaseSync(DB_FILE);
db.exec(`PRAGMA journal_mode=WAL;PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,role TEXT NOT NULL,pass TEXT NOT NULL,created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS listings(id INTEGER PRIMARY KEY,owner_id INTEGER REFERENCES users(id),name TEXT NOT NULL,area TEXT NOT NULL,type TEXT NOT NULL,price INTEGER NOT NULL,phone TEXT,address TEXT,lat REAL,lng REAL,facilities TEXT DEFAULT '[]',available_from TEXT,status TEXT DEFAULT 'pending',v_owner INTEGER DEFAULT 0,v_property INTEGER DEFAULT 0,v_photos INTEGER DEFAULT 0,created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS favorites(user_id INTEGER REFERENCES users(id),listing_id INTEGER REFERENCES listings(id),PRIMARY KEY(user_id,listing_id));
CREATE TABLE IF NOT EXISTS requests(id INTEGER PRIMARY KEY,user_id INTEGER REFERENCES users(id),listing_id INTEGER REFERENCES listings(id),message TEXT,move_in TEXT,status TEXT DEFAULT 'sent',created TEXT DEFAULT CURRENT_TIMESTAMP,UNIQUE(user_id,listing_id));`);

// ---------- helpers ----------
const TYPES=['hostel','room','shared','flat','house','portion','guest','hotel'];
const hash=(pw)=>{const s=crypto.randomBytes(16);return s.toString('hex')+':'+crypto.scryptSync(pw,s,64).toString('hex')};
const check=(pw,h)=>{const [s,k]=h.split(':');const a=crypto.scryptSync(pw,Buffer.from(s,'hex'),64),b=Buffer.from(k,'hex');return a.length===b.length&&crypto.timingSafeEqual(a,b)};
const b64=(b)=>Buffer.from(b).toString('base64url');
const sign=(p)=>{const body=b64(JSON.stringify({...p,exp:Date.now()+7*864e5}));return body+'.'+crypto.createHmac('sha256',SECRET).update(body).digest('base64url')};
const verify=(t)=>{try{const [body,sig]=t.split('.');const e=crypto.createHmac('sha256',SECRET).update(body).digest('base64url');if(sig.length!==e.length||!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(e)))return null;const p=JSON.parse(Buffer.from(body,'base64url'));return p.exp>Date.now()?p:null}catch(e){return null}};
class HttpErr extends Error{constructor(c,m){super(m);this.c=c}}
const bad=(m)=>new HttpErr(400,m);
const str=(v,min,max,label)=>{if(typeof v!=='string')throw bad(label+' is required');v=v.trim();if(v.length<min||v.length>max)throw bad(label+' must be '+min+' to '+max+' characters');return v};
const km=(a,b,c,d)=>{const r=x=>x*Math.PI/180,h=Math.sin(r(c-a)/2)**2+Math.cos(r(a))*Math.cos(r(c))*Math.sin(r(d-b)/2)**2;return Math.round(12742*Math.asin(Math.sqrt(h))*10)/10};
const pubUser=(u)=>({id:u.id,name:u.name,email:u.email,role:u.role});
const hits={};const limit=(ip,max)=>{const k=ip+Math.floor(Date.now()/6e4);hits[k]=(hits[k]||0)+1;if(hits[k]>max)throw new HttpErr(429,'Too many attempts. Try again in a minute.')};
setInterval(()=>{for(const k in hits)if(+k.slice(-8)<Math.floor(Date.now()/6e4)-1)delete hits[k]},3e5).unref();

// geocoding via OpenStreetMap Nominatim (free, no key; keep volume low, see usage policy)
const gc=new Map();
async function geocode(q){q=q.trim().toLowerCase();if(gc.has(q))return gc.get(q);
 const r=await fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=pk&q='+encodeURIComponent(q),{headers:{'User-Agent':'AccommodationFinder/1.0 (contact: '+(process.env.ADMIN_EMAIL||'admin@example.com')+')'},signal:AbortSignal.timeout(6000)});
 if(!r.ok)throw new Error('geocoder '+r.status);const j=await r.json();const v=j[0]?{lat:+j[0].lat,lng:+j[0].lon,label:j[0].display_name}:null;gc.set(q,v);return v}

const shape=(l,from)=>({id:l.id,name:l.name,area:l.area,type:l.type,price:l.price,facilities:JSON.parse(l.facilities),available_from:l.available_from,
 verified:{owner:!!l.v_owner,property:!!l.v_property,photos:!!l.v_photos},lat:l.lat,lng:l.lng,
 distance_km:from&&l.lat!=null?km(from.lat,from.lng,l.lat,l.lng):null,status:l.status});

// ---------- routes ----------
const R=[];const route=(m,p,h)=>R.push([m,new RegExp('^'+p.replace(/:(\w+)/g,'(?<$1>[^/]+)')+'$'),h]);
const need=(c,...roles)=>{if(!c.user)throw new HttpErr(401,'Please log in');if(roles.length&&!roles.includes(c.user.role))throw new HttpErr(403,'Not allowed');return c.user};

route('POST','/api/signup',c=>{limit(c.ip,10);const name=str(c.body.name,2,80,'Name'),email=str(c.body.email,5,120,'Email').toLowerCase(),pw=str(c.body.password,8,100,'Password');
 if(!/^\S+@\S+\.\S+$/.test(email))throw bad('Enter a valid email');const role=c.body.role==='owner'?'owner':'tenant';
 if(db.prepare('SELECT 1 FROM users WHERE email=?').get(email))throw new HttpErr(409,'That email already has an account');
 const id=Number(db.prepare('INSERT INTO users(name,email,role,pass) VALUES(?,?,?,?)').run(name,email,role,hash(pw)).lastInsertRowid);
 const u={id,name,email,role};return[201,{user:u,token:sign({id,role})}]});
route('POST','/api/login',c=>{limit(c.ip,10);const email=str(c.body.email,5,120,'Email').toLowerCase(),pw=str(c.body.password,1,100,'Password');
 const u=db.prepare('SELECT * FROM users WHERE email=?').get(email);if(!u||!check(pw,u.pass))throw new HttpErr(401,'Wrong email or password');
 return[200,{user:pubUser(u),token:sign({id:u.id,role:u.role})}]});
route('GET','/api/me',c=>[200,{user:pubUser(need(c))}]);

route('GET','/api/geocode',async c=>{limit(c.ip,30);const q=str(c.query.q||'',3,120,'Query');try{const g=await geocode(q);return[200,g||{lat:null,lng:null}]}catch(e){throw new HttpErr(502,'Location lookup is unavailable right now')}});

route('GET','/api/listings',async c=>{let from=null;
 if(c.query.lat&&c.query.lng)from={lat:+c.query.lat,lng:+c.query.lng};
 else if(c.query.where){try{from=await geocode(c.query.where+', Pakistan')}catch(e){}}
 if(from&&!(Number.isFinite(from.lat)&&Number.isFinite(from.lng)))from=null;
 const rows=db.prepare("SELECT * FROM listings WHERE status='approved'").all();
 return[200,{from:from?{lat:from.lat,lng:from.lng,label:from.label||null}:null,listings:rows.map(l=>shape(l,from))}]});

route('POST','/api/listings',async c=>{const u=need(c,'owner','admin');const b=c.body;
 const name=str(b.name,3,100,'Property name'),area=str(b.area,2,80,'Area'),phone=str(b.phone,7,20,'Phone'),type=b.type;
 if(!TYPES.includes(type))throw bad('Unknown accommodation type');const price=Math.round(+b.price);if(!(price>=1000&&price<=1e6))throw bad('Price must be between 1,000 and 1,000,000');
 const fac=Array.isArray(b.facilities)?[...new Set(b.facilities.map(Number))].filter(i=>Number.isInteger(i)&&i>=0&&i<=6):[];
 const address=typeof b.address==='string'?b.address.trim().slice(0,200):'';let lat=null,lng=null;
 if(Number.isFinite(+b.lat)&&Number.isFinite(+b.lng)&&b.lat!==''&&b.lat!=null){lat=+b.lat;lng=+b.lng}
 else{try{const g=await geocode((address||area)+', Pakistan');if(g){lat=g.lat;lng=g.lng}}catch(e){}}
 const id=Number(db.prepare('INSERT INTO listings(owner_id,name,area,type,price,phone,address,lat,lng,facilities,available_from) VALUES(?,?,?,?,?,?,?,?,?,?,?)').run(u.id,name,area,type,price,phone,address,lat,lng,JSON.stringify(fac),/^\d{4}-\d{2}-\d{2}$/.test(b.available_from||'')?b.available_from:new Date().toISOString().slice(0,10)).lastInsertRowid);
 return[201,{id,status:'pending',located:lat!=null}]});
route('GET','/api/my/listings',c=>{const u=need(c);return[200,{listings:db.prepare('SELECT * FROM listings WHERE owner_id=? ORDER BY id DESC').all(u.id).map(l=>shape(l))}]});

route('GET','/api/favorites',c=>{const u=need(c);return[200,{ids:db.prepare('SELECT listing_id FROM favorites WHERE user_id=?').all(u.id).map(r=>r.listing_id)}]});
route('POST','/api/favorites/:id',c=>{const u=need(c),id=+c.params.id;if(!db.prepare("SELECT 1 FROM listings WHERE id=? AND status='approved'").get(id))throw new HttpErr(404,'Listing not found');
 const has=db.prepare('SELECT 1 FROM favorites WHERE user_id=? AND listing_id=?').get(u.id,id);
 if(has)db.prepare('DELETE FROM favorites WHERE user_id=? AND listing_id=?').run(u.id,id);else db.prepare('INSERT INTO favorites VALUES(?,?)').run(u.id,id);return[200,{saved:!has}]});

route('POST','/api/requests',c=>{const u=need(c),id=+c.body.listing_id;const l=db.prepare("SELECT * FROM listings WHERE id=? AND status='approved'").get(id);if(!l)throw new HttpErr(404,'Listing not found');
 if(l.owner_id===u.id)throw bad('You cannot request your own property');const msg=str(c.body.message||'Hello, is this still available?',2,1000,'Message');
 if(db.prepare('SELECT 1 FROM requests WHERE user_id=? AND listing_id=?').get(u.id,id))throw new HttpErr(409,'You already requested this place');
 const rid=Number(db.prepare('INSERT INTO requests(user_id,listing_id,message,move_in) VALUES(?,?,?,?)').run(u.id,id,msg,/^\d{4}-\d{2}-\d{2}$/.test(c.body.move_in||'')?c.body.move_in:null).lastInsertRowid);return[201,{id:rid,status:'sent'}]});
route('GET','/api/requests',c=>{const u=need(c);return[200,{requests:db.prepare('SELECT r.id,r.listing_id,l.name,r.message,r.move_in,r.status,r.created FROM requests r JOIN listings l ON l.id=r.listing_id WHERE r.user_id=? ORDER BY r.id DESC').all(u.id)}]});
route('GET','/api/owner/requests',c=>{const u=need(c,'owner','admin');return[200,{requests:db.prepare('SELECT r.id,l.name AS listing,t.name AS tenant,t.email,r.message,r.move_in,r.status,r.created FROM requests r JOIN listings l ON l.id=r.listing_id JOIN users t ON t.id=r.user_id WHERE l.owner_id=? ORDER BY r.id DESC').all(u.id)}]});
route('POST','/api/owner/requests/:id',c=>{const u=need(c,'owner','admin');const st=c.body.status;if(!['accepted','declined'].includes(st))throw bad('Status must be accepted or declined');
 const r=db.prepare('SELECT r.id FROM requests r JOIN listings l ON l.id=r.listing_id WHERE r.id=? AND l.owner_id=?').get(+c.params.id,u.id);if(!r)throw new HttpErr(404,'Request not found');db.prepare('UPDATE requests SET status=? WHERE id=?').run(st,r.id);return[200,{status:st}]});

// moderation: nothing is verified until an admin approves it
route('GET','/api/admin/pending',c=>{need(c,'admin');return[200,{listings:db.prepare("SELECT l.*,u.name AS owner_name,u.email AS owner_email FROM listings l JOIN users u ON u.id=l.owner_id WHERE l.status='pending' ORDER BY l.id").all()}]});
route('POST','/api/admin/listings/:id',c=>{need(c,'admin');const id=+c.params.id,b=c.body;if(!['approved','rejected'].includes(b.decision))throw bad('Decision must be approved or rejected');
 if(!db.prepare('SELECT 1 FROM listings WHERE id=?').get(id))throw new HttpErr(404,'Listing not found');
 db.prepare('UPDATE listings SET status=?,v_owner=?,v_property=?,v_photos=? WHERE id=?').run(b.decision,b.decision==='approved'&&b.v_owner?1:0,b.decision==='approved'&&b.v_property?1:0,b.decision==='approved'&&b.v_photos?1:0,id);return[200,{id,status:b.decision}]});

// ---------- server ----------
const MIME={'.html':'text/html; charset=utf-8','.css':'text/css','.js':'text/javascript','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.ico':'image/x-icon'};
const PUB=path.join(__dirname,'public');
http.createServer(async(req,res)=>{
 const send=(code,obj)=>{res.writeHead(code,{'Content-Type':'application/json','X-Content-Type-Options':'nosniff','Cache-Control':'no-store'});res.end(JSON.stringify(obj))};
 try{const url=new URL(req.url,'http://x');
  if(url.pathname.startsWith('/api/')){
   let body={};if(req.method==='POST'){let n=0;const ch=[];for await(const d of req){n+=d.length;if(n>1e5)throw new HttpErr(413,'Request too large');ch.push(d)}const t=Buffer.concat(ch).toString();if(t){try{body=JSON.parse(t)}catch(e){throw bad('Body must be valid JSON')}}}
   const tk=(req.headers.authorization||'').replace(/^Bearer /,'');const p=tk&&verify(tk);const user=p?db.prepare('SELECT id,name,email,role FROM users WHERE id=?').get(p.id)||null:null;
   for(const [m,re,h] of R){if(m!==req.method)continue;const mt=re.exec(url.pathname);if(!mt)continue;
    const [code,out]=await h({req,body,user,ip:req.socket.remoteAddress||'?',params:mt.groups||{},query:Object.fromEntries(url.searchParams)});return send(code,out)}
   return send(404,{error:'Not found'})}
  if(req.method!=='GET')return send(405,{error:'Method not allowed'});
  let f=path.normalize(path.join(PUB,url.pathname==='/'?'index.html':decodeURIComponent(url.pathname)));
  if(!f.startsWith(PUB)||!fs.existsSync(f)||fs.statSync(f).isDirectory())f=path.join(PUB,'index.html');
  res.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream','X-Content-Type-Options':'nosniff'});fs.createReadStream(f).pipe(res);
 }catch(e){if(e instanceof HttpErr)return send(e.c,{error:e.message});console.error(e);send(500,{error:'Something went wrong'})}
}).listen(PORT,()=>console.log('Accommodation Finder running at http://localhost:'+PORT));

// ---------- first-run setup ----------
if(!db.prepare("SELECT 1 FROM users WHERE role='admin'").get()){
 const email=(process.env.ADMIN_EMAIL||'admin@example.com').toLowerCase(),pw=process.env.ADMIN_PASSWORD||crypto.randomBytes(9).toString('base64url');
 db.prepare('INSERT OR IGNORE INTO users(name,email,role,pass) VALUES(?,?,?,?)').run('Moderator',email,'admin',hash(pw));
 console.log('Admin created: '+email+(process.env.ADMIN_PASSWORD?'':'  password: '+pw+'  (shown once; set ADMIN_PASSWORD in .env to choose your own)'))}
if(!db.prepare('SELECT 1 FROM listings').get()&&process.env.SEED!=='0'){
 const a=db.prepare("SELECT id FROM users WHERE role='admin'").get().id;
 [['Green Nest Hostel','Johar Town','hostel',15000,31.4697,74.2728,[0,1,2,3,4],'2026-10-01',1,1,1],['Scholars Lodge','Raiwind Road','hostel',12000,31.4000,74.2200,[0,2,4],'2026-10-20',1,1,0],
  ['Quiet room near the canal','Valencia Town','room',22000,31.4000,74.2300,[0,1,4,5],'2026-10-10',1,0,0],['3-bed shared flat','Wapda Town','shared',18000,31.4380,74.2750,[0,1,2,4,5,6],'2026-11-01',1,1,1],
  ['Garden-floor portion','Model Town','portion',45000,31.4800,74.3250,[0,1,2,4,5,6],'2026-10-15',1,1,1],['Sunrise Guest House','Gulberg','guest',38000,31.5120,74.3430,[0,1,2,3,4,6],'2026-10-01',1,1,0]]
 .forEach(s=>db.prepare("INSERT INTO listings(owner_id,name,area,type,price,lat,lng,facilities,available_from,status,v_owner,v_property,v_photos,phone) VALUES(?,?,?,?,?,?,?,?,?,'approved',?,?,?,'demo')").run(a,s[0],s[1],s[2],s[3],s[4],s[5],JSON.stringify(s[6]),s[7],s[8],s[9],s[10]));
 console.log('Seeded 6 demo listings (approximate coordinates). Set SEED=0 to skip.')}
