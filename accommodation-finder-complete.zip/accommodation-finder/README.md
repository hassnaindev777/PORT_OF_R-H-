# Accommodation Finder: backend

Zero dependencies. Needs **Node.js 22.5 or newer** (`node -v`). Data lives in a SQLite file (`data.db`).

## Run it
1. `cp .env.example .env` and edit it (set SECRET, ADMIN_EMAIL, ADMIN_PASSWORD).
2. `npm start`
3. Open http://localhost:3000

## Roles
- **tenant**: search, save, send requests
- **owner**: submit listings (stay "pending" and private), see and answer requests
- **admin** (moderator): approve or reject listings and grant the three badges one by one

## API (JSON, send `Authorization: Bearer <token>`)
| Method | Path | Who |
|---|---|---|
| POST | /api/signup, /api/login | anyone |
| GET | /api/me | logged in |
| GET | /api/listings?where=NUST or ?lat=&lng= | anyone (approved only, adds distance_km) |
| GET | /api/geocode?q=University name | anyone |
| POST | /api/listings | owner |
| GET | /api/my/listings | owner |
| GET, POST | /api/favorites, /api/favorites/:id | logged in |
| GET, POST | /api/requests | logged in |
| GET, POST | /api/owner/requests, /api/owner/requests/:id | owner |
| GET | /api/admin/pending | admin |
| POST | /api/admin/listings/:id `{decision, v_owner, v_property, v_photos}` | admin |

## Deploy
Any Node host with a persistent disk works (Render, Railway, Fly.io, a VPS). Set the env vars from `.env.example`,
start command `npm start`, and put it behind HTTPS (hosts do this for you). Back up `data.db` regularly.
Serverless hosts with no persistent disk (e.g. plain Vercel) will lose the database.

## Notes
- Passwords are hashed with scrypt. Login tokens are signed and expire after 7 days.
- Distances use OpenStreetMap Nominatim (free, no key, light use only). For heavy traffic switch to a paid geocoder.
- The 6 seeded listings use approximate coordinates and a placeholder phone. Set `SEED=0` to skip them.
- Not built yet (suggested phase 2): photo upload, reviews, password reset by email, SMS/email notifications, online payment, in-app messaging.

## Handover checklist
1. Create `.env` from `.env.example`: set a long random `SECRET`, your real `ADMIN_EMAIL` and a strong `ADMIN_PASSWORD`, and `SEED=0` so the 6 sample listings are not created.
2. Deploy (Render/Railway/Fly.io/VPS). Attach a persistent disk and point `DB_FILE` at it. A `Dockerfile` is included (data goes in `/data`).
3. Log in with the admin account. The "Pending review" card in **My places** is the moderation screen: tick the badges earned, then Approve or Reject.
4. Back up the `data.db` file regularly.
5. Add a custom domain and confirm the site is served over HTTPS.
